from django.contrib import admin
from .models import ToDoItem, Course


# Register your models here.

admin.site.register(ToDoItem)

admin.site.register(Course)

